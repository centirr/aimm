# CS2-Cheat-Base
Cheat base for Counter-Strike 2.

- Windows Only
- DirectX Only

# Preview
![preview](https://user-images.githubusercontent.com/59938902/233790180-a5d20ad6-75c3-4724-99a6-206be7f21f01.png)

## How to use
1. Download [CS2-Cheat-Base source](https://github.com/KisSsArt/CS2-Cheat-Base/archive/master.zip).
2. Compile the project using Visual Studio (use build configuration `Release | x64`).
3. Find `Cheat-Base.dll` into `_output` folder.
4. Inject .dll into `cs2.exe` process (MANUAL MAP ONLY).
5. Enjoy!

⚠️ **If you use cheats, your account may be banned. Use at your own risk!**

## Dependencies
- [imgui](https://github.com/ocornut/imgui)
- [Json](https://github.com/nlohmann/json)
- [STB](https://github.com/cristeigabriel/STB)
- [kiero](https://github.com/Rebzzel/kiero)
