#pragma once

struct ImVec2;
struct Vector;

bool worldToScreen(Vector& origin, ImVec2& out);