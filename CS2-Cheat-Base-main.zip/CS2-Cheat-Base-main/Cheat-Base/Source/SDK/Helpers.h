#pragma once

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

namespace Helpers
{
	ImWchar* getFontGlyphRanges() noexcept;
}