#pragma once

#include <cstdint>

struct GameTick_t {
public:
	int value;
};