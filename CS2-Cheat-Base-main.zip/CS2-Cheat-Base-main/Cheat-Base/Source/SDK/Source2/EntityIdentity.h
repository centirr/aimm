#pragma once

#include "../Schema.h"

class EntityIdentity {
public:
	SCHEMA(const char*, designerName, "CEntityIdentity", "m_designerName");
};