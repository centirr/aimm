#pragma once

#include "BaseEntity.h"

class EconEntity : public BaseEntity {
public:
};