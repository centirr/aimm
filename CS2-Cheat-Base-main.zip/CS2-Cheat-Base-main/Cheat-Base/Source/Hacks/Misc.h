#pragma once

struct UserCmd;

namespace Misc
{
	void BunnyHop(UserCmd* cmd);
}