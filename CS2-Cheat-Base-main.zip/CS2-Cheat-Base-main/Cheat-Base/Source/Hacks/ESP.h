#pragma once 

struct ImDrawList;

namespace ESP
{
	void render(ImDrawList* list);
}