#pragma once

struct ImDrawList;

namespace Visuals
{
	void NoScopeCrosshair(ImDrawList* drawList);
}