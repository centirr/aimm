#pragma once

#define CLIENTDLL "client.dll"
#define ENGINE2DLL "engine2.dll"
#define SCHEMASYSTEMDLL "schemasystem.dll"
#define SDL3DLL "SDL3.dll"